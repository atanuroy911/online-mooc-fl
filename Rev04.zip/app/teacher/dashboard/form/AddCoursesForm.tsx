// AddCoursesForm.tsx
import React from 'react';
import { TextField, Button, Container, Grid, Typography } from '@mui/material';

const AddCoursesForm = () => {
    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        // Add your form submission logic here
    };

    return (
        <Container>
            <Typography variant="h4" component="h2" gutterBottom>
                Add Course
            </Typography>
            <form onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <TextField
                            required
                            fullWidth
                            id="courseName"
                            label="Course Name"
                            variant="outlined"
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            required
                            fullWidth
                            id="courseDescription"
                            label="Course Description"
                            multiline
                            rows={4}
                            variant="outlined"
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            required
                            fullWidth
                            id="courseCode"
                            label="Course Code"
                            variant="outlined"
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            required
                            fullWidth
                            id="courseCredits"
                            label="Course Credits"
                            variant="outlined"
                            type="number"
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <Button type="submit" variant="contained" color="primary">
                            Add Course
                        </Button>
                    </Grid>
                </Grid>
            </form>
        </Container>
    );
};

export default AddCoursesForm;
