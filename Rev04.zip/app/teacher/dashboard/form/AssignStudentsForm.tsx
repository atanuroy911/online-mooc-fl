// AssignStudentsForm.tsx
import React, { useState } from 'react';
import { TextField, Button, Container, Grid, Typography, FormControl, InputLabel, Select, MenuItem } from '@mui/material';

const AssignStudentsForm = () => {
    const [selectedStudents, setSelectedStudents] = useState<number[]>([]);

    const handleStudentChange = (event: React.ChangeEvent<{ value: unknown }>) => {
        setSelectedStudents(event.target.value as number[]);
    };

    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        // Add your form submission logic here
    };

    return (
        <Container>
            <Typography variant="h4" component="h2" gutterBottom>
                Assign Students
            </Typography>
            <form onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <FormControl fullWidth>
                            <InputLabel id="course-select-label">Select Course</InputLabel>
                            <Select
                                labelId="course-select-label"
                                id="course-select"
                                label="Select Course"
                                fullWidth
                            >
                                <MenuItem value={1}>Course 1</MenuItem>
                                <MenuItem value={2}>Course 2</MenuItem>
                                {/* Add more courses as needed */}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                        <FormControl fullWidth>
                            <InputLabel id="student-select-label">Select Student(s)</InputLabel>
                            <Select
                                labelId="student-select-label"
                                id="student-select"
                                label="Select Student(s)"
                                multiple
                                value={selectedStudents}
                                onChange={handleStudentChange}
                                fullWidth
                            >
                                <MenuItem value={1}>Student 1</MenuItem>
                                <MenuItem value={2}>Student 2</MenuItem>
                                {/* Add more students as needed */}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                        <Button type="submit" variant="contained" color="primary">
                            Assign Students
                        </Button>
                    </Grid>
                </Grid>
            </form>
        </Container>
    );
};

export default AssignStudentsForm;
