import React from 'react';
import AssignStudentsForm from '../form/AssignStudentsForm';

const AssignStudentsPage = () => {
    return (
        <div>
            <AssignStudentsForm />
        </div>
    );
};

export default AssignStudentsPage;
