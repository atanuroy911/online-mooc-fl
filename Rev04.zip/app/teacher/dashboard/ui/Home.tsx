// Home.tsx

import Chart from "../chart/chart";


const Home = () => {

    return <>
        <div className="container">
            <Chart />

        </div>
    </>
}
export default Home;
