import React from 'react';
import AddCoursesForm from '../form/AddCoursesForm';

const AddCoursesPage = () => {
    return (
        <div>
            <AddCoursesForm />
        </div>
    );
};

export default AddCoursesPage;
